﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Controls.Primitives;
using System.Windows.Threading;
using System.Windows.Forms;
using System.IO;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow_2.xaml
    /// </summary>
    public partial class MainWindow_2 : Window
    {
        private ObservableCollection<LectureList> _lectureList = new ObservableCollection<LectureList>();
        bool isDragging = false;
        bool isPlaying = false;

        MainWindow_1 mwSelect;

        public MainWindow_2()
        {
            InitializeComponent();

            //Load_File("d:\\UserList");
            slider_seek.ApplyTemplate();
            Thumb thumb = (slider_seek.Template.FindName("PART_Track", slider_seek) as Track).Thumb;
            thumb.MouseEnter += new System.Windows.Input.MouseEventHandler(thumb_MouseEnter);
            thumb.DragStarted += new DragStartedEventHandler(slider_seeker_DragStarted);
            thumb.DragCompleted += new DragCompletedEventHandler(slider_seeker_DragCompleted);
            showMedia.ScrubbingEnabled = true;
            CloseAll.caMW2 = this;

        }

        #region joyAdded
        private void CheckIsFirsTtime()
        {
            if (CloseAll.caMW1 == null)
            {
                mwSelect = new MainWindow_1();
                mwSelect.Show();
            }
            else
                CloseAll.caMW1.Visibility = Visibility.Visible;
        }
        #endregion

        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.F11:
                    CheckIsFirsTtime();
                    this.Visibility = Visibility.Hidden;
                    break;
            }
        }

        private void thumb_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                //showMedia.Position = TimeSpan.FromSeconds(slider_seek.Value); 
                MouseButtonEventArgs args = new MouseButtonEventArgs(

                 e.MouseDevice, e.Timestamp, MouseButton.Left);

                args.RoutedEvent = MouseLeftButtonDownEvent;

                (sender as Thumb).RaiseEvent(args);
            }

        }

        private void slider_seeker_DragStarted(object sender, DragStartedEventArgs e)
        {
            isDragging = true;
            showMedia.Pause();
        }

        private void slider_seeker_DragCompleted(object sender, DragCompletedEventArgs e)
        {
            isDragging = false;
            showMedia.Position = TimeSpan.FromSeconds(slider_seek.Value);
            if (isPlaying)
            {
                showMedia.Play();
                isPlaying = true;
            }
        }

        private void showMedia_MediaOpened(object sender, RoutedEventArgs e)
        {
            if (showMedia.NaturalDuration.HasTimeSpan)
            {
                TimeSpan ts = TimeSpan.FromSeconds(showMedia.NaturalDuration.TimeSpan.TotalSeconds);
                slider_seek.Maximum = ts.TotalSeconds;
            }
        }

        private void setShowMedia(string filename)
        {
            showMedia.Source = new Uri(filename);
            DispatcherTimer dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Tick += new EventHandler(timer_Tick);
            dispatcherTimer.Interval = TimeSpan.FromMilliseconds(100);//new TimeSpan(0, 0, 1);
            dispatcherTimer.Start();
            Encoder.setMedia(showMedia.Source.OriginalString);
        }

        void timer_Tick(object sender, EventArgs e)
        {
            if (!isDragging)
            {
                slider_seek.Value = showMedia.Position.TotalSeconds;
            }
            else
            {
                showMedia.Position = TimeSpan.FromSeconds(slider_seek.Value);
            }
        }

        private void Load_File(string FileDirection)
        {
            _lectureList.Clear();

            string[] alldirs = Directory.GetDirectories(FileDirection);
            foreach (string dirName in alldirs)
            {
                LectureList p1 = new LectureList()
                {
                    FileChecked = true,
                    FileName = new DirectoryInfo(dirName).Name,
                    Count = "",
                    Date = "",
                    fileDirection = dirName,
                    isfile = false
                };
                _lectureList.Add(p1);
            }


            string[] allfiles = Directory.GetFiles(FileDirection, "*.wmv*"/*, System.IO.SearchOption.AllDirectories*/);
            foreach (string fileName in allfiles)
            {
                LectureList p1 = new LectureList()
                {
                    FileChecked = true,
                    FileName = System.IO.Path.GetFileName(fileName),
                    Count = "0",
                    Date = "0",
                    fileDirection = fileName,
                    isfile = true
                };
                _lectureList.Add(p1);
            }
            DataContext = _lectureList;

            Directory_Text.Text = FileDirection;
        }

        private void Image_MouseLeftButtonUp_1(object sender, MouseButtonEventArgs e) // tmp Open
        {
            //OpenFileDialog ofd;
            //ofd = new OpenFileDialog();
            //ofd.AddExtension = true;
            //ofd.DefaultExt = "*.*";
            //ofd.Filter = "Windows Media (*.wmv)|*.wmv";
            //ofd.ShowDialog();

            string folderDirection;
            FolderBrowserDialog forderbrowser = new FolderBrowserDialog();
            forderbrowser.ShowDialog();
            if (forderbrowser.SelectedPath != @"")
            {
                folderDirection = forderbrowser.SelectedPath;
                Load_File(folderDirection);
            }


            //try
            //{
            //    setShowMedia(ofd.FileName);
            //    //showMedia.Play();
            //    showMedia.Pause();
            //    showMedia.Stop();
            //    image_PlayPause.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(@"\Image/임시재생버튼.png", UriKind.Relative));
            //    Array.ForEach(Directory.GetFiles(@"d:\tmp\"), File.Delete);
            //}
            //catch { new NullReferenceException("Error"); }
        }

        private void Image_MouseLeftButtonUp_2(object sender, MouseButtonEventArgs e) // play or pause
        {
            if (showMedia.Source != null)
            {
                if (!isPlaying)
                {
                    image_PlayPause.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(@"\Image/일시정지버튼.png", UriKind.Relative));
                    showMedia.Play();
                    isPlaying = true;
                }
                else
                {
                    image_PlayPause.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(@"\Image/임시재생버튼.png", UriKind.Relative));
                    showMedia.Pause();
                    isPlaying = false;
                }
            }
        }

        private void Image_MouseLeftButtonUp_3(object sender, MouseButtonEventArgs e) // stop
        {
            image_PlayPause.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(@"\Image/임시재생버튼.png", UriKind.Relative));
            showMedia.Stop();
            isPlaying = false;
        }

        private void Image_MouseLeftButtonUp_4(object sender, MouseButtonEventArgs e) // PreMerge
        {
            if (showMedia.Source != null)
            {
                showMedia.Stop();
                image_PlayPause.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(@"\Image/임시재생버튼.png", UriKind.Relative));

                OpenFileDialog ofd;
                ofd = new OpenFileDialog();
                ofd.AddExtension = true;
                ofd.DefaultExt = "*.*";
                ofd.Filter = "Windows Media (*.wmv)|*.wmv";
                ofd.ShowDialog();

                try
                {
                    if (ofd.FileName != @"")
                    {
                        string newMediafileName = Encoder.PreMerge(ofd.FileName);
                        setShowMedia(newMediafileName);
                    }
                }
                catch { new NullReferenceException("Error"); }

            }
        }

        private void Image_MouseLeftButtonUp_5(object sender, MouseButtonEventArgs e) // NextMerge
        {
            if (showMedia.Source != null)
            {
                showMedia.Stop();
                image_PlayPause.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(@"\Image/임시재생버튼.png", UriKind.Relative));

                OpenFileDialog ofd;
                ofd = new OpenFileDialog();
                ofd.AddExtension = true;
                ofd.DefaultExt = "*.*";
                ofd.Filter = "Windows Media (*.wmv)|*.wmv";
                ofd.ShowDialog();

                if (ofd.FileName != null)
                {
                    string newMediafileName = Encoder.NextMerge(ofd.FileName);
                    setShowMedia(newMediafileName);
                }
            }
        }

        private void Image_MouseLeftButtonUp_6(object sender, MouseButtonEventArgs e) // PreCut
        {
            if (showMedia.Source != null)
            {
                if (slider_seek.Value != slider_seek.Maximum && slider_seek.Value != slider_seek.Minimum)
                {
                    string newMediafileName = Encoder.PreCut(slider_seek.Value);
                    showMedia.Stop();
                    setShowMedia(newMediafileName);
                    image_PlayPause.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(@"\Image/임시재생버튼.png", UriKind.Relative));
                }
            }
        }

        private void Image_MouseLeftButtonUp_7(object sender, MouseButtonEventArgs e) // NextCut
        {
            if (showMedia.Source != null)
            {
                if (slider_seek.Value != slider_seek.Maximum && slider_seek.Value != slider_seek.Minimum)
                {
                    string newMediafileName = Encoder.NextCut(slider_seek.Value);
                    showMedia.Stop();
                    setShowMedia(newMediafileName);
                    image_PlayPause.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(@"\Image/임시재생버튼.png", UriKind.Relative));
                }
            }
        }

        private void Image_MouseLeftButtonUp_8(object sender, MouseButtonEventArgs e) // Encode
        {
            if (showMedia.Source != null)
                Encoder.Encode();
        }

        private void Image_MouseLeftButtonUp_9(object sender, MouseButtonEventArgs e) // Save
        {
            if (showMedia.Source != null)
            {
                //SaveFileDialog sfd;
                //sfd = new SaveFileDialog();
                //sfd.AddExtension = true;
                //sfd.DefaultExt = "*.*";
                //sfd.Filter = "Media Files (*.*)|*.*";
                //sfd.ShowDialog();

                //if (sfd.FileName != @"")
                //{
                Encoder.Save(showMedia.Source.OriginalString, @"d:\UserList\"/*,sfd.FileName*/);
                Load_File("d:\\UserList");
                //}               
            }
        }

        private void Image_MouseLeftButtonUp_10(object sender, MouseButtonEventArgs e) // Delete
        {
            if (showMedia.Source != null)
            {
                showMedia.Stop();
                showMedia.Source = null;
                Encoder.removeMedia();
                image_PlayPause.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(@"\Image/임시재생버튼.png", UriKind.Relative));
                Array.ForEach(Directory.GetFiles(@"d:\tmp\"), File.Delete);
            }
        }

        private void Window_Closed_1(object sender, EventArgs e)
        {
            if (showMedia.Source != null)
            {
                showMedia.Source = null;
                Encoder.removeMedia();
            }
            Array.ForEach(Directory.GetFiles(@"d:\tmp\"), File.Delete);
        }

        private void lectureSaveList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            showMedia.Stop();
            System.Windows.Controls.ListView item = sender as System.Windows.Controls.ListView;
            object obj = item.SelectedItem;
            LectureList ll = obj as LectureList;
            if (ll.isfile)
            {
                try
                {
                    setShowMedia(ll.fileDirection);
                    showMedia.Pause();
                    showMedia.Stop();
                    image_PlayPause.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(@"\Image/임시재생버튼.png", UriKind.Relative));
                    Array.ForEach(Directory.GetFiles(@"d:\tmp\"), File.Delete);
                }
                catch { new NullReferenceException("Error"); }
            }
            else
            {
                Load_File(ll.fileDirection);
            }
        }

    }

    public class LectureList : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private bool _fileChecked = false;
        public bool FileChecked
        {
            get { return _fileChecked; }
            set
            {
                if (value != _fileChecked)
                {
                    _fileChecked = value;
                    if (PropertyChanged != null)
                    {
                        PropertyChanged(this, new PropertyChangedEventArgs("FileChecked"));
                    }
                }
            }
        }
        public string FileName { get; set; }
        public string Count { get; set; }
        public string Date { get; set; }
        public string fileDirection { get; set; }
        public bool isfile { get; set; }

    }
}
